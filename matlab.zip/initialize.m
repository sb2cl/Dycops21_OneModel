% Initialize the path of the project.

addpath('./build');
addpath('./data');
addpath('./utils');
